
  # Design Mobile Creator Flow

  This is a code bundle for Design Mobile Creator Flow. The original project is available at https://www.figma.com/design/qtj7NlQxj7SSlTL5E0NDrU/Design-Mobile-Creator-Flow.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  