import { useState } from 'react';
import { Menu } from 'lucide-react';
import { Login } from './components/Login';
import { Home } from './components/Home';
import { Campaigns } from './components/Campaigns';
import { CampaignDetail } from './components/CampaignDetail';
import { UploadContent } from './components/UploadContent';
import { Wallet } from './components/Wallet';
import { Profile } from './components/Profile';
import { Insights } from './components/Insights';
import { AgencyCreators } from './components/AgencyCreators';
import { LoginModal } from './components/LoginModal';
import { MobileNav } from './components/MobileNav';
import logo from 'figma:asset/fcad7446971be733d3427a6b22f8f64253529daf.png';
import { Currency } from './utils/currency';

export type Screen = 'home' | 'campaigns' | 'wallet' | 'insights' | 'profile' | 'login' | 'campaign' | 'upload' | 'agency-creators';

export type AccountType = 'creator' | 'agency';

export interface Campaign {
  id: string;
  title: string;
  brand: string;
  rate: number;
  status: 'offered' | 'accepted' | 'upload_required' | 'uploaded' | 'in_review' | 'needs_revision' | 'approved' | 'ready_to_post' | 'posted_submitted' | 'posted_verified' | 'paid';
  platform: string;
  deadline: string;
  brief?: string;
  deliverables?: string[];
  currentStep?: string;
  needsAction?: boolean;
  lastFeedback?: string;
  currentVersion?: number;
}

export interface Creator {
  id: string;
  name: string;
  email: string;
  phone: string;
  platform: string;
  followers: string;
  niche: string;
  profilePhoto?: string;
  availableBalance: number;
  activeCampaigns: number;
  status: 'active' | 'pending' | 'inactive';
}

export interface OfferData {
  brand: string;
  brandLogo: string;
  campaignTitle: string;
  amount: number;
  counterAmount: number;
  deliverables: string[];
  deadline: string;
  expiresIn: string;
}

export interface FeedbackData {
  items: string[];
}

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [accountType, setAccountType] = useState<AccountType>('creator');
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [selectedCreator, setSelectedCreator] = useState<Creator | null>(null);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [pendingAction, setPendingAction] = useState<string | null>(null);
  const [userCurrency, setUserCurrency] = useState<Currency>('NGN'); // User's preferred currency
  const [showMobileNav, setShowMobileNav] = useState(false);

  // Mock managed creators state
  const [managedCreators, setManagedCreators] = useState([
    {
      id: '1',
      displayName: 'Sarah Johnson',
      niche: 'Beauty & Skincare',
      baseRate: 85000,
      currency: 'NGN' as Currency,
      socialAccounts: [
        { id: '1', platform: 'tiktok' as const, handle: 'sarahbeauty', followers: 250000, rateOverride: 90000 },
        { id: '2', platform: 'instagram' as const, handle: 'sarah_johnson', followers: 180000 }
      ],
      status: 'active' as const
    },
    {
      id: '2',
      displayName: 'Mike Tech',
      niche: 'Technology',
      baseRate: 120000,
      currency: 'NGN' as Currency,
      socialAccounts: [
        { id: '3', platform: 'youtube' as const, handle: 'miketechreview', followers: 500000, rateOverride: 150000 },
        { id: '4', platform: 'tiktok' as const, handle: 'miketech', followers: 320000 }
      ],
      status: 'active' as const
    }
  ]);

  // Mock campaigns
  const mockCampaigns: Campaign[] = [
    {
      id: '1',
      title: 'Summer Skincare Campaign',
      brand: 'GlowSkin Co.',
      rate: 75000,
      status: 'offered',
      platform: 'TikTok',
      deadline: 'Jun 15',
      currentStep: 'New offer',
      needsAction: true,
      deliverables: [
        '60-second TikTok video showcasing our new sunscreen',
        'Include product demo and before/after',
        'Use trending audio (we\'ll provide list)',
        'Tag @glowskinco and use #GlowAllSummer'
      ]
    },
    {
      id: '2',
      title: 'Fitness Challenge',
      brand: 'FitLife',
      rate: 120000,
      status: 'in_draft',
      platform: 'Instagram',
      deadline: 'Jun 20',
      currentStep: 'Drafting',
      needsAction: true
    },
    {
      id: '3',
      title: 'Tech Review',
      brand: 'TechNova',
      rate: 90000,
      status: 'submitted',
      platform: 'YouTube',
      deadline: 'Jun 10',
      currentStep: 'Under review',
      needsAction: false
    },
    {
      id: '4',
      title: 'Beauty Tutorial',
      brand: 'StyleHub',
      rate: 65000,
      status: 'needs_revision',
      platform: 'TikTok',
      deadline: 'Jun 25',
      currentStep: 'Needs revision',
      needsAction: true,
      lastFeedback: 'Please adjust the lighting in the first 10 seconds and add our brand hashtag in the caption.',
      currentVersion: 1
    },
    {
      id: '5',
      title: 'Fashion Haul',
      brand: 'TrendWear',
      rate: 85000,
      status: 'posted_verified',
      platform: 'Instagram',
      deadline: 'May 30',
      currentStep: 'Post verified',
      needsAction: false
    }
  ];

  // Mock creators (for agency mode)
  const mockCreators: Creator[] = [
    {
      id: '1',
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      phone: '+1 555 0100',
      platform: 'TikTok',
      followers: '125K',
      niche: 'Beauty & Skincare',
      availableBalance: 2450,
      activeCampaigns: 3,
      status: 'active'
    },
    {
      id: '2',
      name: 'Mike Chen',
      email: 'mike@example.com',
      phone: '+1 555 0101',
      platform: 'YouTube',
      followers: '350K',
      niche: 'Tech Reviews',
      availableBalance: 5200,
      activeCampaigns: 2,
      status: 'active'
    },
    {
      id: '3',
      name: 'Emma Davis',
      email: 'emma@example.com',
      phone: '+1 555 0102',
      platform: 'Instagram',
      followers: '89K',
      niche: 'Fitness',
      availableBalance: 1850,
      activeCampaigns: 1,
      status: 'active'
    }
  ];

  // Mock wallet data
  const walletBalance = {
    available: 325000,
    pending: 120000,
    locked: 0,
    lifetime: 1245000
  };

  const mockTransactions = [
    {
      id: '1',
      type: 'campaign_earning',
      amount: 75000,
      status: 'cleared',
      campaign: 'Summer Skincare Campaign',
      date: 'Jan 5, 2026'
    },
    {
      id: '2',
      type: 'referral_bonus',
      amount: 4500,
      status: 'cleared',
      date: 'Jan 4, 2026'
    },
    {
      id: '3',
      type: 'campaign_earning',
      amount: 120000,
      status: 'pending',
      campaign: 'Fitness Challenge',
      date: 'Jan 3, 2026'
    },
    {
      id: '4',
      type: 'withdrawal',
      amount: 100000,
      status: 'cleared',
      date: 'Jan 1, 2026'
    }
  ];

  // Mock referral data
  const mockReferralData = {
    referralCode: 'CREATOR2026',
    totalEarnings: 43200,
    totalReferred: 8,
    referrals: [
      {
        id: '1',
        name: 'Sarah Johnson',
        joinedDate: 'Dec 15, 2025',
        earnings: 12500,
        status: 'active' as const
      },
      {
        id: '2',
        name: 'Mike Chen',
        joinedDate: 'Dec 20, 2025',
        earnings: 8700,
        status: 'active' as const
      },
      {
        id: '3',
        name: 'Emma Davis',
        joinedDate: 'Jan 2, 2026',
        earnings: 22000,
        status: 'active' as const
      }
    ]
  };

  // Mock insights data
  const mockInsightsStats = {
    postsSubmitted: 12,
    postsApproved: 10,
    postsPublished: 8,
    totalViews: 1250000,
    totalEngagements: 87500,
    avgViewsPerPost: 156250,
    engagementRate: 7.0,
    earningsUnlocked: 325000,
    earningsPending: 120000
  };

  const mockInsightsPosts = [
    {
      id: '1',
      campaign: 'Summer Skincare Campaign',
      platform: 'TikTok',
      postUrl: 'https://tiktok.com/@creator/video/123',
      datePosted: 'May 28, 2026',
      views: 245000,
      likes: 18500,
      comments: 1250,
      shares: 890,
      status: 'verified',
      paymentStatus: 'paid',
      amount: 75000
    },
    {
      id: '2',
      campaign: 'Fashion Haul',
      platform: 'Instagram',
      postUrl: 'https://instagram.com/p/ABC123',
      datePosted: 'May 30, 2026',
      views: 185000,
      likes: 12800,
      comments: 780,
      shares: 450,
      status: 'verified',
      paymentStatus: 'unlocked',
      amount: 85000
    }
  ];

  const handleNavigate = (screen: Screen, campaign?: Campaign) => {
    if (campaign) {
      setSelectedCampaign(campaign);
    }
    setCurrentScreen(screen);
  };

  const handleViewCampaign = (campaign: Campaign) => {
    setSelectedCampaign(campaign);
    setCurrentScreen('campaign');
  };

  const handleBackToCampaigns = () => {
    setCurrentScreen('campaigns');
    setSelectedCampaign(null);
  };

  const handleBackToHome = () => {
    setCurrentScreen('home');
    setSelectedCampaign(null);
  };

  const handleProtectedAction = (action: string, callback: () => void) => {
    if (!isAuthenticated) {
      setPendingAction(action);
      setShowLoginModal(true);
    } else {
      callback();
    }
  };

  const handleLogin = () => {
    setIsAuthenticated(true);
    setShowLoginModal(false);
    
    // Execute pending action if any
    if (pendingAction) {
      // Handle the pending action
      setPendingAction(null);
    }
  };

  const handleWithdraw = () => {
    handleProtectedAction('withdraw', () => {
      alert('Withdrawal initiated. Funds will arrive in 24-48 hours.');
    });
  };

  const handleAccept = (amount: number) => {
    if (selectedCampaign) {
      selectedCampaign.status = 'accepted';
    }
    setCurrentScreen('campaign');
  };

  const handleDecline = () => {
    alert('Offer declined. This link will no longer be valid.');
    setCurrentScreen('campaigns');
  };

  const handleUploadSubmit = () => {
    // Handle upload submission
    if (selectedCampaign) {
      selectedCampaign.status = 'submitted';
      selectedCampaign.currentStep = 'Under review';
    }
    console.log('Upload submitted');
    handleBackToCampaigns();
  };

  const handlePriorityAction = (id: string, type: string) => {
    const campaign = mockCampaigns.find(c => c.id === id);
    if (campaign) {
      handleViewCampaign(campaign);
    }
  };

  const handleFeedbackUpload = () => {
    if (selectedCampaign) {
      selectedCampaign.status = 'approved';
    }
    setCurrentScreen('campaign');
  };

  const handlePostConfirm = () => {
    if (selectedCampaign) {
      selectedCampaign.status = 'posted';
    }
    setCurrentScreen('campaign');
  };

  const handleSelectCreator = (creator: Creator) => {
    setSelectedCreator(creator);
    // Switch context to show this creator's campaigns
  };

  const handleRequestAuth = (action: string) => {
    handleProtectedAction(action, () => {});
  };

  // Managed creators handlers
  const handleAddCreator = (data: any) => {
    const newCreator = {
      id: Date.now().toString(),
      displayName: data.displayName,
      niche: data.niche || 'General',
      baseRate: data.baseRate,
      currency: data.currency,
      socialAccounts: data.socialAccounts.map((acc: any) => ({
        ...acc,
        id: Date.now().toString() + Math.random()
      })),
      status: 'active' as const
    };
    setManagedCreators([...managedCreators, newCreator]);
    console.log('Creator added:', newCreator);
  };

  const handleUpdateCreator = (creatorId: string, data: Partial<typeof managedCreators[0]>) => {
    setManagedCreators(managedCreators.map(creator =>
      creator.id === creatorId ? { ...creator, ...data } : creator
    ));
    console.log('Creator updated:', creatorId, data);
  };

  const handleDeleteCreator = (creatorId: string) => {
    setManagedCreators(managedCreators.filter(c => c.id !== creatorId));
    console.log('Creator deleted:', creatorId);
  };

  const handleAddSocialAccount = (creatorId: string, account: any) => {
    setManagedCreators(managedCreators.map(creator => {
      if (creator.id === creatorId) {
        return {
          ...creator,
          socialAccounts: [...creator.socialAccounts, { ...account, id: Date.now().toString() }]
        };
      }
      return creator;
    }));
    console.log('Social account added:', creatorId, account);
  };

  const handleUpdateSocialAccount = (creatorId: string, accountId: string, data: any) => {
    setManagedCreators(managedCreators.map(creator => {
      if (creator.id === creatorId) {
        return {
          ...creator,
          socialAccounts: creator.socialAccounts.map(acc =>
            acc.id === accountId ? { ...acc, ...data } : acc
          )
        };
      }
      return creator;
    }));
    console.log('Social account updated:', creatorId, accountId, data);
  };

  const handleDeleteSocialAccount = (creatorId: string, accountId: string) => {
    setManagedCreators(managedCreators.map(creator => {
      if (creator.id === creatorId) {
        return {
          ...creator,
          socialAccounts: creator.socialAccounts.filter(acc => acc.id !== accountId)
        };
      }
      return creator;
    }));
    console.log('Social account deleted:', creatorId, accountId);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] overflow-x-hidden">
      {/* Desktop Navigation */}
      {currentScreen !== 'campaign' && (
        <div className="hidden lg:block sticky top-0 z-50 bg-[#0A0A0A]/95 border-b border-white/[0.06] backdrop-blur-xl">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              {/* Logo */}
              <div className="flex items-center gap-3">
                <img src={logo} alt="Dobble Tap" className="h-8 w-8" />
                <span className="text-sm font-semibold text-white">Dobble Tap</span>
              </div>

              {/* Navigation */}
              <nav className="flex items-center gap-1">
                {accountType === 'agency' && (
                  <>
                    <button
                      onClick={() => setCurrentScreen('home')}
                      className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                        currentScreen === 'home'
                          ? 'bg-white text-black'
                          : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
                      }`}
                    >
                      Home
                    </button>
                    <button
                      onClick={() => setCurrentScreen('agency-creators')}
                      className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                        currentScreen === 'agency-creators'
                          ? 'bg-white text-black'
                          : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
                      }`}
                    >
                      Creators
                    </button>
                  </>
                )}
                {accountType === 'creator' && (
                  <button
                    onClick={() => setCurrentScreen('home')}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                      currentScreen === 'home'
                        ? 'bg-white text-black'
                        : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
                    }`}
                  >
                    Home
                  </button>
                )}
                <button
                  onClick={() => setCurrentScreen('campaigns')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    currentScreen === 'campaigns'
                      ? 'bg-white text-black'
                      : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
                  }`}
                >
                  Campaigns
                </button>
                <button
                  onClick={() => setCurrentScreen('wallet')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    currentScreen === 'wallet'
                      ? 'bg-white text-black'
                      : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
                  }`}
                >
                  Wallet
                </button>
                <button
                  onClick={() => setCurrentScreen('insights')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    currentScreen === 'insights'
                      ? 'bg-white text-black'
                      : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
                  }`}
                >
                  Insights
                </button>
                <button
                  onClick={() => setCurrentScreen('profile')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    currentScreen === 'profile'
                      ? 'bg-white text-black'
                      : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
                  }`}
                >
                  Profile
                </button>
                <button
                  onClick={() => isAuthenticated ? setIsAuthenticated(false) : setCurrentScreen('login')}
                  className="ml-2 px-3 py-1.5 rounded-lg text-sm font-medium bg-white/[0.05] text-slate-300 hover:bg-white/[0.08] transition-colors border border-white/[0.08]"
                >
                  {isAuthenticated ? 'Account' : 'Login'}
                </button>
                <button
                  onClick={() => setAccountType(accountType === 'creator' ? 'agency' : 'creator')}
                  className="ml-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#0ea5e9]/10 text-[#0ea5e9] hover:bg-[#0ea5e9]/20 transition-colors border border-[#0ea5e9]/20"
                  title="Toggle account type"
                >
                  {accountType === 'creator' ? 'Switch to Agency' : 'Switch to Creator'}
                </button>
              </nav>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Header */}
      {currentScreen !== 'campaign' && (
        <div className="lg:hidden sticky top-0 z-50 bg-[#0A0A0A]/95 border-b border-white/[0.06] backdrop-blur-xl">
          <div className="px-4 h-14 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <img src={logo} alt="Dobble Tap" className="h-7 w-7" />
              <span className="text-sm font-semibold text-white">Dobble Tap</span>
            </div>
            <button
              onClick={() => setShowMobileNav(true)}
              className="p-2 text-slate-400 hover:text-white transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Mobile Navigation Drawer */}
      <MobileNav
        isOpen={showMobileNav}
        onClose={() => setShowMobileNav(false)}
        currentScreen={currentScreen}
        accountType={accountType}
        onNavigate={(screen) => {
          setCurrentScreen(screen);
          setShowMobileNav(false);
        }}
        isAuthenticated={isAuthenticated}
        onToggleAuth={() => {
          if (isAuthenticated) {
            setIsAuthenticated(false);
          } else {
            setCurrentScreen('login');
          }
          setShowMobileNav(false);
        }}
        onToggleAccountType={() => {
          setAccountType(accountType === 'creator' ? 'agency' : 'creator');
        }}
      />

      {/* Main Content */}
      <div className="pb-4">
        {/* Screens */}
        {currentScreen === 'login' && (
          <Login onLogin={handleLogin} />
        )}
        {currentScreen === 'campaigns' && (
          <Campaigns
            campaigns={mockCampaigns}
            walletBalance={walletBalance}
            onViewCampaign={handleViewCampaign}
            onWithdraw={handleWithdraw}
            onNavigateToWallet={() => setCurrentScreen('wallet')}
            currency={userCurrency}
          />
        )}
        {currentScreen === 'campaign' && selectedCampaign && (
          <CampaignDetail
            campaign={selectedCampaign}
            onBack={handleBackToCampaigns}
            onAccept={handleAccept}
            onDecline={handleDecline}
            onUploadSubmit={handleUploadSubmit}
            onFeedbackUpload={handleFeedbackUpload}
            onPostConfirm={handlePostConfirm}
            currency={userCurrency}
          />
        )}
        {currentScreen === 'upload' && selectedCampaign && (
          <UploadContent
            campaign={{
              id: selectedCampaign.id,
              title: selectedCampaign.title,
              brand: selectedCampaign.brand,
              status: selectedCampaign.status
            }}
            version={selectedCampaign.currentVersion || 1}
            lastFeedback={selectedCampaign.lastFeedback}
            onBack={handleBackToCampaigns}
            onSubmit={handleUploadSubmit}
          />
        )}
        {currentScreen === 'wallet' && (
          <Wallet
            balance={walletBalance}
            transactions={mockTransactions}
            onWithdraw={handleWithdraw}
            isAuthenticated={isAuthenticated}
            currency={userCurrency}
            bankAccount={{
              id: '1',
              bankName: 'Access Bank',
              accountNumber: '0123456789',
              accountName: 'John Doe'
            }}
            onAddBankDetails={() => setCurrentScreen('profile')}
          />
        )}
        {currentScreen === 'profile' && (
          <Profile
            referralData={mockReferralData}
            isAuthenticated={isAuthenticated}
            onRequestAuth={handleRequestAuth}
            currency={userCurrency}
            onCurrencyChange={setUserCurrency}
            accountType={accountType}
            managedCreators={managedCreators}
            onAddCreator={handleAddCreator}
            onUpdateCreator={handleUpdateCreator}
            onDeleteCreator={handleDeleteCreator}
            onManageCreator={(id) => console.log('Manage creator:', id)}
            onViewCampaigns={(id) => {
              console.log('View campaigns for:', id);
              setCurrentScreen('campaigns');
            }}
            onAddSocialAccount={handleAddSocialAccount}
            onUpdateSocialAccount={handleUpdateSocialAccount}
            onDeleteSocialAccount={handleDeleteSocialAccount}
          />
        )}
        {currentScreen === 'agency-creators' && accountType === 'agency' && (
          <AgencyCreators
            creators={mockCreators}
            onSelectCreator={handleSelectCreator}
            onAddCreator={handleAddCreator}
            currency={userCurrency}
          />
        )}
        {currentScreen === 'insights' && (
          <Insights
            stats={mockInsightsStats}
            posts={mockInsightsPosts}
            engagementData={Array.from({ length: 90 }, (_, i) => ({
              date: `Day ${i + 1}`,
              engagements: Math.floor(Math.random() * 5000) + 2000,
              views: Math.floor(Math.random() * 50000) + 20000,
              likes: Math.floor(Math.random() * 3000) + 1000,
              comments: Math.floor(Math.random() * 500) + 100,
              shares: Math.floor(Math.random() * 300) + 50
            }))}
            currency={userCurrency}
          />
        )}
        {currentScreen === 'home' && (
          <Home
            walletBalance={walletBalance}
            workSummary={{
              pendingOffers: mockCampaigns.filter(c => c.status === 'offered').length,
              needsAction: mockCampaigns.filter(c => c.needsAction).length,
              activeCampaigns: mockCampaigns.filter(c => !['offered', 'paid', 'posted_verified'].includes(c.status)).length,
              nextDeadline: {
                campaign: 'Tech Review',
                date: 'Jun 10',
                daysLeft: 3
              }
            }}
            engagementData={Array.from({ length: 30 }, (_, i) => ({
              date: `Jan ${i + 1}`,
              engagements: Math.floor(Math.random() * 5000) + 2000,
              views: Math.floor(Math.random() * 50000) + 20000,
              likes: Math.floor(Math.random() * 3000) + 1000,
              comments: Math.floor(Math.random() * 500) + 100,
              shares: Math.floor(Math.random() * 300) + 50
            }))}
            priorityItems={mockCampaigns.filter(c => c.needsAction).map(c => ({
              id: c.id,
              type: c.status === 'offered' ? 'offer' : c.status === 'needs_revision' ? 'revision' : c.status === 'ready_to_post' ? 'post_link' : 'proof',
              campaign: c.title,
              message: c.status === 'offered' ? `New offer: ${c.platform} content` : c.status === 'needs_revision' ? 'Feedback received, resubmit required' : c.status === 'ready_to_post' ? 'Content approved, ready to post' : 'Verification needed',
              urgent: c.status === 'needs_revision' || c.status === 'ready_to_post'
            }))}
            onViewOffers={() => setCurrentScreen('campaigns')}
            onViewNeedsAction={() => setCurrentScreen('campaigns')}
            onViewCampaigns={() => setCurrentScreen('campaigns')}
            onHandlePriority={handlePriorityAction}
            onWithdraw={handleWithdraw}
            onNavigateToWallet={() => setCurrentScreen('wallet')}
            currency={userCurrency}
          />
        )}

        {/* Login Modal */}
        {showLoginModal && (
          <LoginModal
            onLogin={handleLogin}
            onClose={() => {
              setShowLoginModal(false);
              setPendingAction(null);
            }}
            message={`Sign in to ${pendingAction || 'continue'}`}
          />
        )}
      </div>
    </div>
  );
}

export default App;