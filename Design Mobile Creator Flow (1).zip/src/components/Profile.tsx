import { Camera, Copy, CheckCircle2, Share2, User, CreditCard, Bell, Users, ChevronRight, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';
import { Referral } from './Referral';
import { PriceCalculator } from './PriceCalculator';
import { ManagedCreatorsList } from './ManagedCreatorsList';
import { AddCreatorModal } from './AddCreatorModal';
import { ManageCreatorModal } from './ManageCreatorModal';
import { formatCurrency, Currency, CURRENCIES } from '../utils/currency';

interface ManagedCreatorData {
  id: string;
  displayName: string;
  niche?: string;
  baseRate: number;
  currency: Currency;
  socialAccounts: Array<{
    id: string;
    platform: 'tiktok' | 'instagram' | 'youtube';
    handle: string;
    followers: number;
    rateOverride?: number;
  }>;
  status: 'active' | 'inactive';
}

interface ProfileProps {
  referralData: {
    referralCode: string;
    totalEarnings: number;
    totalReferred: number;
    referrals: Array<{
      id: string;
      name: string;
      joinedDate: string;
      earnings: number;
      status: 'active' | 'inactive';
    }>;
  };
  isAuthenticated: boolean;
  onRequestAuth: (action: string) => void;
  currency?: Currency;
  onCurrencyChange?: (currency: Currency) => void;
  managedCreators?: ManagedCreatorData[];
  onAddCreator?: (data: any) => void;
  onUpdateCreator?: (creatorId: string, data: Partial<ManagedCreatorData>) => void;
  onDeleteCreator?: (creatorId: string) => void;
  onAddSocialAccount?: (creatorId: string, account: any) => void;
  onUpdateSocialAccount?: (creatorId: string, accountId: string, data: any) => void;
  onDeleteSocialAccount?: (creatorId: string, accountId: string) => void;
  onManageCreator?: (creatorId: string) => void;
  onViewCampaigns?: (creatorId: string) => void;
  accountType?: 'creator' | 'agency';
}

export function Profile({ 
  referralData, 
  isAuthenticated, 
  onRequestAuth, 
  currency = 'NGN', 
  onCurrencyChange,
  managedCreators = [],
  onAddCreator = () => {},
  onUpdateCreator = () => {},
  onDeleteCreator = () => {},
  onAddSocialAccount = () => {},
  onUpdateSocialAccount = () => {},
  onDeleteSocialAccount = () => {},
  onManageCreator = () => {},
  onViewCampaigns = () => {},
  accountType = 'creator'
}: ProfileProps) {
  const [showReferral, setShowReferral] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [showAddCreatorModal, setShowAddCreatorModal] = useState(false);
  const [showManageCreatorModal, setShowManageCreatorModal] = useState(false);
  const [selectedCreatorId, setSelectedCreatorId] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [editMode, setEditMode] = useState(false);

  const selectedCreator = managedCreators.find(c => c.id === selectedCreatorId) || null;

  const handleManageCreator = (creatorId: string) => {
    setSelectedCreatorId(creatorId);
    setShowManageCreatorModal(true);
    onManageCreator(creatorId);
  };

  const handleCloseManageModal = () => {
    setShowManageCreatorModal(false);
    setSelectedCreatorId(null);
  };

  const handleCopyReferral = () => {
    navigator.clipboard.writeText(`https://dobbletap.com/join/${referralData.referralCode}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePhotoUpload = () => {
    if (!isAuthenticated) {
      onRequestAuth('upload profile photo');
    } else {
      // Handle upload
    }
  };

  const handleSave = () => {
    if (!isAuthenticated) {
      onRequestAuth('save profile');
    } else {
      setEditMode(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold text-white mb-8">Profile</h1>

      {/* Currency Selector */}
      <div className="mb-6">
        <div className="bg-[#0D0D0D]/50 border border-white/[0.06] rounded-xl p-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-white mb-1">Preferred Currency</h3>
              <p className="text-xs text-slate-500">Set your default currency for payments and earnings</p>
            </div>
            <select
              value={currency}
              onChange={(e) => onCurrencyChange?.(e.target.value as Currency)}
              className="px-4 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white focus:border-[#0ea5e9] focus:outline-none transition-colors"
            >
              {Object.entries(CURRENCIES).map(([code, info]) => (
                <option key={code} value={code}>
                  {info.symbol} {info.name} ({code})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Profile Section */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#0D0D0D]/50 border border-white/[0.06] rounded-xl p-6"
        >
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-slate-400" />
              <h2 className="text-base font-semibold text-white">Profile</h2>
            </div>
            {!editMode ? (
              <button
                onClick={() => setEditMode(true)}
                className="text-sm text-slate-400 hover:text-white transition-colors"
              >
                Edit
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setEditMode(false)}
                  className="px-3 py-1.5 text-sm text-slate-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="px-3 py-1.5 bg-white text-black rounded-lg text-sm font-medium hover:bg-white/90 transition-colors"
                >
                  Save
                </button>
              </div>
            )}
          </div>

          <div className="flex items-start gap-6">
            {/* Profile Photo */}
            <div className="relative group">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#0ea5e9] to-purple-500 flex items-center justify-center text-white text-2xl font-bold">
                JD
              </div>
              <button
                onClick={handlePhotoUpload}
                className="absolute bottom-0 right-0 w-7 h-7 bg-white text-black rounded-full flex items-center justify-center hover:bg-white/90 transition-colors"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>

            {/* Profile Fields */}
            <div className="flex-1 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-500 mb-2">Name</label>
                  <input
                    type="text"
                    defaultValue="John Doe"
                    disabled={!editMode}
                    className="w-full px-3 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white disabled:text-slate-400 disabled:cursor-not-allowed focus:border-white/[0.12] focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-500 mb-2">Email</label>
                  <input
                    type="email"
                    defaultValue="john@example.com"
                    disabled={!editMode}
                    className="w-full px-3 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white disabled:text-slate-400 disabled:cursor-not-allowed focus:border-white/[0.12] focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-500 mb-2">Phone</label>
                  <input
                    type="tel"
                    defaultValue="+1 555 0100"
                    disabled={!editMode}
                    className="w-full px-3 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white disabled:text-slate-400 disabled:cursor-not-allowed focus:border-white/[0.12] focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-500 mb-2">Primary Platform</label>
                  <select
                    defaultValue="TikTok"
                    disabled={!editMode}
                    className="w-full px-3 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white disabled:text-slate-400 disabled:cursor-not-allowed focus:border-white/[0.12] focus:outline-none transition-colors"
                  >
                    <option>TikTok</option>
                    <option>Instagram</option>
                    <option>YouTube</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-500 mb-2">Niche</label>
                  <input
                    type="text"
                    defaultValue="Beauty & Lifestyle"
                    disabled={!editMode}
                    className="w-full px-3 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white disabled:text-slate-400 disabled:cursor-not-allowed focus:border-white/[0.12] focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-500 mb-2">Followers</label>
                  <input
                    type="text"
                    defaultValue="125K"
                    disabled={!editMode}
                    className="w-full px-3 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white disabled:text-slate-400 disabled:cursor-not-allowed focus:border-white/[0.12] focus:outline-none transition-colors"
                  />
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Bank Details */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[#0D0D0D]/50 border border-white/[0.06] rounded-xl p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <CreditCard className="w-4 h-4 text-slate-400" />
            <h2 className="text-base font-semibold text-white">Bank Details</h2>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-500 mb-2">Bank Name</label>
                <input
                  type="text"
                  placeholder="Chase Bank"
                  className="w-full px-3 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white placeholder:text-slate-600 focus:border-white/[0.12] focus:outline-none transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-2">Account Name</label>
                <input
                  type="text"
                  placeholder="John Doe"
                  className="w-full px-3 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white placeholder:text-slate-600 focus:border-white/[0.12] focus:outline-none transition-colors"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-500 mb-2">Account Number</label>
                <input
                  type="text"
                  placeholder="••••••1234"
                  className="w-full px-3 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white placeholder:text-slate-600 focus:border-white/[0.12] focus:outline-none transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-2">Currency</label>
                <select className="w-full px-3 py-2 bg-white/[0.03] border border-white/[0.06] rounded-lg text-sm text-white focus:border-white/[0.12] focus:outline-none transition-colors">
                  <option>USD</option>
                  <option>EUR</option>
                  <option>GBP</option>
                </select>
              </div>
            </div>

            <div className="pt-4 border-t border-white/[0.06]">
              <p className="text-xs text-slate-500 mb-3">Withdrawals will be sent to this bank account</p>
              <button
                onClick={() => !isAuthenticated && onRequestAuth('save bank details')}
                className="px-4 py-2 bg-white/[0.05] border border-white/[0.06] rounded-lg text-sm font-medium text-white hover:bg-white/[0.08] transition-colors"
              >
                Save Bank Details
              </button>
            </div>
          </div>
        </motion.div>

        {/* Referrals */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[#0D0D0D]/50 border border-white/[0.06] rounded-xl p-6"
        >
          <div className="flex items-center gap-2 mb-6">
            <Users className="w-4 h-4 text-slate-400" />
            <h2 className="text-base font-semibold text-white">Referral Program</h2>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-white/[0.03] rounded-lg p-4">
              <div className="text-xs text-slate-500 mb-1">Your Code</div>
              <div className="text-lg font-bold text-white">{referralData.referralCode}</div>
            </div>
            <div className="bg-white/[0.03] rounded-lg p-4">
              <div className="text-xs text-slate-500 mb-1">Earned</div>
              <div className="text-lg font-bold text-purple-400">{formatCurrency(referralData.totalEarnings, currency)}</div>
            </div>
            <div className="bg-white/[0.03] rounded-lg p-4">
              <div className="text-xs text-slate-500 mb-1">Referred</div>
              <div className="text-lg font-bold text-white">{referralData.totalReferred}</div>
            </div>
          </div>

          <div className="flex items-center gap-3 mb-6">
            <button
              onClick={handleCopyReferral}
              className="flex-1 px-4 py-2.5 bg-white text-black rounded-lg text-sm font-medium hover:bg-white/90 transition-colors flex items-center justify-center gap-2"
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Copy Link
                </>
              )}
            </button>
            <button className="flex-1 px-4 py-2.5 bg-white/[0.05] border border-white/[0.06] rounded-lg text-sm font-medium text-white hover:bg-white/[0.08] transition-colors flex items-center justify-center gap-2">
              <Share2 className="w-4 h-4" />
              Share
            </button>
          </div>

          {/* Referral History */}
          {referralData.referrals.length > 0 && (
            <div className="pt-4 border-t border-white/[0.06]">
              <div className="text-sm font-medium text-white mb-3">Referral History</div>
              <div className="space-y-2">
                {referralData.referrals.map((referral) => (
                  <div
                    key={referral.id}
                    className="flex items-center justify-between py-2 px-3 bg-white/[0.02] rounded-lg"
                  >
                    <div>
                      <div className="text-sm text-white">{referral.name}</div>
                      <div className="text-xs text-slate-500">Joined {referral.joinedDate}</div>
                    </div>
                    <div className="text-sm font-semibold text-purple-400">
                      +{formatCurrency(referral.earnings, currency)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>

        {/* Notifications */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-[#0D0D0D]/50 border border-white/[0.06] rounded-xl p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Bell className="w-4 h-4 text-slate-400" />
            <h2 className="text-base font-semibold text-white">Notifications</h2>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between py-2">
              <div>
                <div className="text-sm text-white mb-0.5">WhatsApp</div>
                <div className="text-xs text-slate-500">Primary notification channel</div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-white/[0.06] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
              </label>
            </div>
            <div className="flex items-center justify-between py-2">
              <div>
                <div className="text-sm text-white mb-0.5">Email</div>
                <div className="text-xs text-slate-500">Campaign updates and receipts</div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-white/[0.06] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
              </label>
            </div>
            <div className="flex items-center justify-between py-2">
              <div>
                <div className="text-sm text-white mb-0.5">SMS</div>
                <div className="text-xs text-slate-500">Urgent notifications only</div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-white/[0.06] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
              </label>
            </div>
          </div>
        </motion.div>

        {/* Managed Creators */}
        {accountType === 'agency' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-[#0D0D0D]/50 border border-white/[0.06] rounded-xl p-6"
          >
            <ManagedCreatorsList
              creators={managedCreators}
              onAddCreator={() => setShowAddCreatorModal(true)}
              onManageCreator={handleManageCreator}
              onViewCampaigns={onViewCampaigns}
            />
          </motion.div>
        )}
      </div>

      {/* Add Creator Modal */}
      <AddCreatorModal
        isOpen={showAddCreatorModal}
        onClose={() => setShowAddCreatorModal(false)}
        onSave={(data) => {
          onAddCreator(data);
          setShowAddCreatorModal(false);
        }}
        defaultCurrency={currency}
      />

      {/* Manage Creator Modal */}
      <ManageCreatorModal
        isOpen={showManageCreatorModal}
        onClose={handleCloseManageModal}
        creator={selectedCreator}
        onSave={(data) => {
          if (selectedCreatorId) {
            onUpdateCreator(selectedCreatorId, data);
          }
          handleCloseManageModal();
        }}
        onDelete={() => {
          if (selectedCreatorId) {
            onDeleteCreator(selectedCreatorId);
          }
          handleCloseManageModal();
        }}
        onAddSocialAccount={(account) => {
          if (selectedCreatorId) {
            onAddSocialAccount(selectedCreatorId, account);
          }
        }}
        onUpdateSocialAccount={(accountId, data) => {
          if (selectedCreatorId) {
            onUpdateSocialAccount(selectedCreatorId, accountId, data);
          }
        }}
        onDeleteSocialAccount={(accountId) => {
          if (selectedCreatorId) {
            onDeleteSocialAccount(selectedCreatorId, accountId);
          }
        }}
      />
    </div>
  );
}