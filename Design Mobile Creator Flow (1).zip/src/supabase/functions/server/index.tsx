import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware
app.use('*', cors());
app.use('*', logger(console.log));

// Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

// Helper: Verify auth token
async function verifyAuth(authHeader: string | null) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.substring(7);
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) return null;
  return user;
}

// Withdraw Endpoints

// POST /make-server-8061e72e/payments/withdraw/initiate
app.post('/make-server-8061e72e/payments/withdraw/initiate', async (c) => {
  try {
    const user = await verifyAuth(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { amount, currency = 'NGN', note } = await c.req.json();

    if (!amount || amount <= 0) {
      return c.json({ error: 'Invalid amount' }, 400);
    }

    // Get user's wallet balance from KV store
    const walletKey = `wallet:${user.id}`;
    const walletData = await kv.get(walletKey);
    const availableBalance = walletData?.available || 0;

    if (amount > availableBalance) {
      return c.json({ error: 'Insufficient balance' }, 400);
    }

    // Create withdrawal request record
    const withdrawalId = crypto.randomUUID();
    const paystackReference = `DTWD-${Date.now()}-${withdrawalId.slice(0, 8)}`;
    
    // SIMULATION: In production, call Paystack API to get authorization URL
    // const paystackResponse = await fetch('https://api.paystack.co/transaction/initialize', {
    //   method: 'POST',
    //   headers: {
    //     'Authorization': `Bearer ${Deno.env.get('PAYSTACK_SECRET_KEY')}`,
    //     'Content-Type': 'application/json'
    //   },
    //   body: JSON.stringify({
    //     email: user.email,
    //     amount: amount * 100, // Paystack uses kobo
    //     reference: paystackReference,
    //     callback_url: `${Deno.env.get('FRONTEND_URL')}/wallet?withdrawal=success`
    //   })
    // });
    
    // SIMULATION URL for demo purposes
    const simulatedAuthUrl = `https://checkout.paystack.com/simulation?reference=${paystackReference}&amount=${amount}`;

    // Create ledger entry to lock funds
    await kv.set(`ledger:${withdrawalId}`, {
      id: withdrawalId,
      userId: user.id,
      entryType: 'withdrawal',
      amount,
      currency,
      status: 'pending',
      note,
      createdAt: new Date().toISOString()
    });

    // Create withdrawal request record
    await kv.set(`withdrawal:${withdrawalId}`, {
      id: withdrawalId,
      userId: user.id,
      amount,
      currency,
      status: 'pending',
      paystackReference,
      paystackAuthorizationUrl: simulatedAuthUrl,
      note,
      createdAt: new Date().toISOString()
    });

    // Lock funds by reducing available balance
    const updatedWallet = {
      ...walletData,
      available: availableBalance - amount,
      pending_withdrawal: (walletData?.pending_withdrawal || 0) + amount
    };
    await kv.set(walletKey, updatedWallet);

    return c.json({
      withdrawalId,
      authorizationUrl: simulatedAuthUrl,
      reference: paystackReference
    });

  } catch (error) {
    console.error('Withdrawal initiation error:', error);
    return c.json({ error: 'Failed to initiate withdrawal' }, 500);
  }
});

// POST /make-server-8061e72e/payments/paystack/webhook
app.post('/make-server-8061e72e/payments/paystack/webhook', async (c) => {
  try {
    // IMPORTANT: In production, verify Paystack signature
    // const signature = c.req.header('x-paystack-signature');
    // const hash = crypto.createHmac('sha512', Deno.env.get('PAYSTACK_SECRET_KEY')).update(JSON.stringify(body)).digest('hex');
    // if (hash !== signature) return c.json({ error: 'Invalid signature' }, 401);

    const body = await c.req.json();
    const { event, data } = body;

    if (event === 'charge.success') {
      const reference = data.reference;
      
      // Find withdrawal by reference
      const withdrawals = await kv.getByPrefix('withdrawal:');
      const withdrawal = withdrawals.find((w: any) => w.paystackReference === reference);
      
      if (!withdrawal) {
        console.error('Withdrawal not found for reference:', reference);
        return c.json({ error: 'Withdrawal not found' }, 404);
      }

      // Update withdrawal status
      await kv.set(`withdrawal:${withdrawal.id}`, {
        ...withdrawal,
        status: 'completed',
        processedAt: new Date().toISOString()
      });

      // Update ledger entry
      const ledgerKey = `ledger:${withdrawal.id}`;
      const ledgerEntry = await kv.get(ledgerKey);
      if (ledgerEntry) {
        await kv.set(ledgerKey, {
          ...ledgerEntry,
          status: 'completed',
          completedAt: new Date().toISOString()
        });
      }

      // Update wallet to finalize withdrawal
      const walletKey = `wallet:${withdrawal.userId}`;
      const walletData = await kv.get(walletKey);
      if (walletData) {
        await kv.set(walletKey, {
          ...walletData,
          pending_withdrawal: (walletData.pending_withdrawal || 0) - withdrawal.amount,
          lifetime_withdrawn: (walletData.lifetime_withdrawn || 0) + withdrawal.amount
        });
      }

      console.log(`Withdrawal ${withdrawal.id} completed successfully`);
      
    } else if (event === 'charge.failed') {
      const reference = data.reference;
      
      // Find and fail withdrawal
      const withdrawals = await kv.getByPrefix('withdrawal:');
      const withdrawal = withdrawals.find((w: any) => w.paystackReference === reference);
      
      if (withdrawal) {
        // Update withdrawal status
        await kv.set(`withdrawal:${withdrawal.id}`, {
          ...withdrawal,
          status: 'failed',
          failureReason: data.gateway_response,
          processedAt: new Date().toISOString()
        });

        // Update ledger entry
        await kv.set(`ledger:${withdrawal.id}`, {
          ...(await kv.get(`ledger:${withdrawal.id}`)),
          status: 'failed',
          completedAt: new Date().toISOString()
        });

        // Release locked funds
        const walletKey = `wallet:${withdrawal.userId}`;
        const walletData = await kv.get(walletKey);
        if (walletData) {
          await kv.set(walletKey, {
            ...walletData,
            available: (walletData.available || 0) + withdrawal.amount,
            pending_withdrawal: (walletData.pending_withdrawal || 0) - withdrawal.amount
          });
        }

        console.log(`Withdrawal ${withdrawal.id} failed and funds released`);
      }
    }

    return c.json({ status: 'webhook processed' });

  } catch (error) {
    console.error('Webhook processing error:', error);
    return c.json({ error: 'Webhook processing failed' }, 500);
  }
});

// Managed Creators Endpoints

// GET /make-server-8061e72e/managed-creators
app.get('/make-server-8061e72e/managed-creators', async (c) => {
  try {
    const user = await verifyAuth(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const creators = await kv.getByPrefix(`managed_creator:${user.id}:`);
    return c.json({ creators });

  } catch (error) {
    console.error('Failed to fetch managed creators:', error);
    return c.json({ error: 'Failed to fetch creators' }, 500);
  }
});

// POST /make-server-8061e72e/managed-creators
app.post('/make-server-8061e72e/managed-creators', async (c) => {
  try {
    const user = await verifyAuth(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { displayName, niche, baseRate, currency, socialAccounts } = await c.req.json();

    if (!displayName || !baseRate || !socialAccounts || socialAccounts.length === 0) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    const creatorId = crypto.randomUUID();
    const creator = {
      id: creatorId,
      managerUserId: user.id,
      displayName,
      niche: niche || 'General',
      baseRate,
      currency: currency || 'NGN',
      status: 'active',
      socialAccounts: socialAccounts.map((acc: any) => ({
        id: crypto.randomUUID(),
        platform: acc.platform,
        handle: acc.handle,
        followers: acc.followers,
        rateOverride: acc.rateOverride,
        createdAt: new Date().toISOString()
      })),
      createdAt: new Date().toISOString()
    };

    await kv.set(`managed_creator:${user.id}:${creatorId}`, creator);

    return c.json({ creator });

  } catch (error) {
    console.error('Failed to create managed creator:', error);
    return c.json({ error: 'Failed to create creator' }, 500);
  }
});

// PUT /make-server-8061e72e/managed-creators/:id
app.put('/make-server-8061e72e/managed-creators/:id', async (c) => {
  try {
    const user = await verifyAuth(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const creatorId = c.req.param('id');
    const updates = await c.req.json();

    const creatorKey = `managed_creator:${user.id}:${creatorId}`;
    const existingCreator = await kv.get(creatorKey);

    if (!existingCreator) {
      return c.json({ error: 'Creator not found' }, 404);
    }

    const updatedCreator = {
      ...existingCreator,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    await kv.set(creatorKey, updatedCreator);

    return c.json({ creator: updatedCreator });

  } catch (error) {
    console.error('Failed to update managed creator:', error);
    return c.json({ error: 'Failed to update creator' }, 500);
  }
});

// Campaign Upload Submission Endpoints

// POST /make-server-8061e72e/campaigns/:campaignId/submit-content
app.post('/make-server-8061e72e/campaigns/:campaignId/submit-content', async (c) => {
  try {
    const user = await verifyAuth(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const campaignId = c.req.param('campaignId');
    const { type, url, note, fileName, fileSize } = await c.req.json();

    if (!type || !url) {
      return c.json({ error: 'Missing required fields: type and url' }, 400);
    }

    if (type !== 'file' && type !== 'drive_link') {
      return c.json({ error: 'Invalid type. Must be file or drive_link' }, 400);
    }

    // Get campaign
    const campaignKey = `campaign:${campaignId}`;
    const campaign = await kv.get(campaignKey);

    if (!campaign) {
      return c.json({ error: 'Campaign not found' }, 404);
    }

    // Verify user owns this campaign
    if (campaign.creatorId !== user.id) {
      return c.json({ error: 'Forbidden' }, 403);
    }

    // Create asset record
    const assetId = crypto.randomUUID();
    const versionNumber = (campaign.currentVersion || 0) + 1;
    
    const asset = {
      id: assetId,
      campaignId: campaignId,
      creatorId: user.id,
      assetType: 'draft_video',
      assetSource: type,
      assetUrl: url,
      fileName: fileName || null,
      fileSize: fileSize || null,
      versionNumber,
      note: note || null,
      status: 'pending_review',
      createdAt: new Date().toISOString()
    };

    await kv.set(`asset:${assetId}`, asset);

    // Update campaign status
    const updatedCampaign = {
      ...campaign,
      status: 'in_review',
      currentStep: 'review',
      currentVersion: versionNumber,
      lastSubmittedAt: new Date().toISOString(),
      lastAssetId: assetId,
      updatedAt: new Date().toISOString()
    };

    await kv.set(campaignKey, updatedCampaign);

    // Generate review token
    const reviewToken = crypto.randomUUID();
    const reviewTokenRecord = {
      token: reviewToken,
      campaignId: campaignId,
      assetId: assetId,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days
    };

    await kv.set(`review_token:${reviewToken}`, reviewTokenRecord);

    // In production, send notification to agency/client
    // const reviewUrl = `${Deno.env.get('FRONTEND_URL')}/review/${reviewToken}`;
    // await sendNotification(campaign.agencyEmail, reviewUrl);

    console.log(`Content submitted for campaign ${campaignId}, asset ${assetId}, version ${versionNumber}`);

    return c.json({
      success: true,
      assetId,
      versionNumber,
      reviewToken,
      campaign: updatedCampaign
    });

  } catch (error) {
    console.error('Content submission error:', error);
    return c.json({ error: 'Failed to submit content' }, 500);
  }
});

// GET /make-server-8061e72e/campaigns/:campaignId/assets
app.get('/make-server-8061e72e/campaigns/:campaignId/assets', async (c) => {
  try {
    const user = await verifyAuth(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const campaignId = c.req.param('campaignId');

    // Get all assets for this campaign
    const allAssets = await kv.getByPrefix('asset:');
    const campaignAssets = allAssets.filter((asset: any) => asset.campaignId === campaignId);

    // Sort by version number descending
    campaignAssets.sort((a: any, b: any) => b.versionNumber - a.versionNumber);

    return c.json({ assets: campaignAssets });

  } catch (error) {
    console.error('Failed to fetch campaign assets:', error);
    return c.json({ error: 'Failed to fetch assets' }, 500);
  }
});

// GET /make-server-8061e72e/review/:token
app.get('/make-server-8061e72e/review/:token', async (c) => {
  try {
    const token = c.req.param('token');

    const reviewTokenRecord = await kv.get(`review_token:${token}`);

    if (!reviewTokenRecord) {
      return c.json({ error: 'Invalid or expired review link' }, 404);
    }

    // Check if token is expired
    const expiresAt = new Date(reviewTokenRecord.expiresAt);
    if (expiresAt < new Date()) {
      return c.json({ error: 'Review link has expired' }, 410);
    }

    // Get asset
    const asset = await kv.get(`asset:${reviewTokenRecord.assetId}`);
    if (!asset) {
      return c.json({ error: 'Asset not found' }, 404);
    }

    // Get campaign
    const campaign = await kv.get(`campaign:${reviewTokenRecord.campaignId}`);
    if (!campaign) {
      return c.json({ error: 'Campaign not found' }, 404);
    }

    return c.json({
      asset,
      campaign: {
        id: campaign.id,
        title: campaign.title,
        brand: campaign.brand,
        platform: campaign.platform
      }
    });

  } catch (error) {
    console.error('Failed to fetch review data:', error);
    return c.json({ error: 'Failed to fetch review data' }, 500);
  }
});

// Health check
app.get('/make-server-8061e72e/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

Deno.serve(app.fetch);